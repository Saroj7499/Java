import java.io.*;
class Ass5SetC1 extends Thread
{
	String str;
	Ass5SetC1 (String str)
	{
		this.str=str;
	}
	public void run()
	{
		File f=new File(str);
		while(true)
		{
			if(f.exists())
			{
				System.out.println(str+"File is  present");
				break;
			}
			
			else
			{
				System.out.println(str+"File is not present");
			}
			try
			{	
				Thread.sleep(500);
			}
			catch(Exception e)
			{
			}
		}
	}
	public static void main(String args[])
	{
		Ass5SetC1 arr[]=new Ass5SetC1[args.length];
		for(int i=0;i<args.length;i++)
		{
			arr[i]=new Ass5SetC1(args[i]);
			arr[i].start();
		}
	}
}
