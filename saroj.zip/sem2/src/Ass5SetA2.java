import java.io.*;
import java.util.*;
class Ass5SetA2 extends Thread
{	int no1,no2;
	static int total=0;
	int total1;
	static int a[]=new int[1000];
	Ass5SetA2(int no1,int no2)
	{
		this.no1=no1;
		this.no2=no2;
	}
	public void run()
	{
		for(int i=no1;i<no2;i++)
		{
			total=total+a[i];
		}
		sum(total);
	}
	public void sum(int total)
	{
		total1=total;
	}
	public static void main(String args[])throws IOException
	{
		try
		{

		 Random rand=new Random();

		for(int i=0;i<5;i++)
		{
			a[i]=rand.nextInt(10);
			System.out.print(a[i]+"\t");	
		}

		Ass5SetA2 t1=new Ass5SetA2(0,3);
		t1.start();
		t1.join();

       		 Ass5SetA2 t2=new Ass5SetA2(3,5);
	        t2.start();
	        t2.join();
		System.out.println("Addition is:"+total);
		}
		catch(Exception e)
		{}

	}
}
