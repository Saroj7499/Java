import java.io.*;
class Ass5SetC1 extends Thread
{
	String str;
	Ass5SetC1 (String str)
	{
		this.str=str;
	}
	public void run()
	{
		File f=new File(str);
		BufferedReader br=new BufferedReader(new FileReader(str));
		while(true)
		{
			if(f.exists())
			{
				System.out.println(str+"File is  present");
				break;
			}
			
			else
			{
				System.out.println(str+"File is not present");
			}
			try
			{	
				Thread.sleep(500);
			}
			catch(Exception e)
			{
			}
		}
	}
	public static void main(String args[])
	{
		File f=new File(".");
		File f1[]=f.listFiles();
		Ass5SetC1 arr[]=new Ass5SetC1[f1.length];
		for(int i=0;i<args.length;i++)
		{
			arr[i]=new Ass5SetC1(f1[i]+"");
			arr[i].start();
		}
	}
}
