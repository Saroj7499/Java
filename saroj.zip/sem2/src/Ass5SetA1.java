import java.io.*;
class Ass5SetA1 extends Thread
{
	String str;
	Ass5SetA1(String str)
	{
		this.str=str;
	}
	public void run()
	{
		while(true)
		{
			System.out.println(str);
			
		}
	}

	public static void main(String args[])
	{
		Ass5SetA1 t1=new Ass5SetA1("*************I am 1st Thread***************");
		t1.start();
	//	t1.join();
		Ass5SetA1 t2=new Ass5SetA1("I am 2nd Thread");
                t2.start();
               // t2.join();
		
	}
}
