import java.io.*;


public class Ass3seta3
{

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nEnter array size:\t");
		int no=Integer.parseInt(br.readLine());
		LightMotorVehicle l[]=new LightMotorVehicle[no];
		HeavyMotorVehicle h[]=new HeavyMotorVehicle[no];
		int lc=0, hc=0;
		for(int i=0;i<no;i++)
		{
			System.out.println("\nEnter company name:\t");
			String company=br.readLine();
			System.out.println("\nEnter price:\t");
			float price=Float.parseFloat(br.readLine());
			System.out.println("Enter type of vehicle:\n 1 for LightMotorVehicle\n and 2 for HeavyMotorVehicle:\t");
			int t=Integer.parseInt(br.readLine());
			if(t==1)
			{
				System.out.println("\nEnter Mileage:\t");
				float mileage=Float.parseFloat(br.readLine());
				l[lc]=new LightMotorVehicle(company,price,mileage);
				lc++;
				
			}
			else
			{
				System.out.println("\nEnter Capacity in tones\t");
				float capacity=Float.parseFloat(br.readLine());
				h[hc]=new HeavyMotorVehicle(company,price,capacity);
				hc++;
			}
			for( i=0;i<lc;i++)
			{
				l[i].displayl();
			}
			for( i=0;i<hc;i++)
			{
				h[i].display();
			}
		}
		// TODO Auto-generated method stub

	}

}
