
public class Vehicle
{
	String company;
	float price;
	Vehicle(String c,float p)
	{
		company=c;
		price=p;
	}
	void display()
	{
		System.out.println("\nCompany:\t"+company+"\nPrice:\t"+price);
	}
}
