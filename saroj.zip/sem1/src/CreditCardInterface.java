import java.io.IOException;


public interface CreditCardInterface 
{
	public void viewCreditAmount();
	public void useCard() throws IOException;
	public void payCard() throws IOException;
	public void increaseLimit();
}
