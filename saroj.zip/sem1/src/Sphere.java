
public class Sphere extends Shape
{
	double rad;
	public Sphere()
	{
		
	}
	public Sphere(double r)
	{
		rad=r;
	}
	void calc_area()
	{
		area=4.0*3.14*rad*rad;
		System.out.println("\nArea of Sphere is:\t"+area);
	}
	void calc_volume()
	{
		volume=(4/3)*3.14*rad*rad*rad;
		System.out.println("\n Volume of Sphere is:\t"+volume);
	}
}
