import calci.*;
public class Demo 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Calculator ob = new Calculator();
		ob.add(10,20);
		ob.sub(20,10);
		ob.mult(5,4);
		ob.div(6,2);
		// TODO Auto-generated method stub

	}

}
