import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Ass6SetAdd2 extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4;
	JTextField t1,t2,t3,t4;
	JPanel p1;
	JButton b1,b2;
	public Ass6SetAdd2()
	{
		l1=new JLabel("Decimal");
		l2=new JLabel("Binary");
		l3=new JLabel("Octal");
		l4=new JLabel("Hexadecimal");
		t1=new JTextField(10);
		t2=new JTextField(10);
		t3=new JTextField(10);
		t4=new JTextField(10);
		b1=new JButton("Calculate");
		b2=new JButton("Exit");
		p1=new JPanel();
		add(p1);
		p1.add(l1);
		p1.add(t1);
		p1.add(l2);
		p1.add(t2);
		p1.add(l3);
		p1.add(t3);
		p1.add(l4);
		p1.add(t4);
		b1.addActionListener(this);
		b2.addActionListener(this);
		t1.addActionListener(this);
		t2.addActionListener(this);
		t3.addActionListener(this);
		t4.addActionListener(this);
		p1.add(b1);
		p1.add(b2);
		p1.setLayout(new GridLayout(5,2));
		setSize(400,400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent e)
	{
		int n;
		if(e.getSource()==b1)
		{
			n=Integer.parseInt(t1.getText());
			t2.setText(Integer.toBinaryString(n));
			t3.setText(Integer.toOctalString(n));
			t4.setText(Integer.toHexString(n));
		}
		if(e.getSource()==b2)
		{
			System.exit(0);
		}
		
	}
	public static void main(String args[])
	{
		new Ass6SetAdd2();
	}
}

