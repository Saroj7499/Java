import java.io.*;
import SY.*;
import TY.*;
public class Student2
{
	int rn,symarks,tymarks;
	char grade;
	float per;
	String name;
	Student2(int r,String n,int sy,int ty)
	{
		rn=r;
		name=n;
		symarks=sy;
		tymarks=ty;
	}
	public void findResult()
	{
		per=(((symarks+tymarks)/500.00f)*100.00f);
		if(per>=70.00f)
			grade='A';
		else if(per<70.00f && per>=60.00f)
			grade='B';
		else if(per<60.00f && per>=50.00f)
			grade='C';
		else if(per<50.00f && per>=40.00f)
			grade='P';
		else
			grade='F';
	}
	public void display()
	{
		System.out.println("\nRoll no:\t"+rn+"\nName:\t"+name+"\n Percentage:\t"+per+"\nGrade:\t"+grade);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException  
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nEnter size of array:\t");
		int no=Integer.parseInt(br.readLine());
		Student2 s[]=new Student2[no];
		SYMarks sm=new SYMarks();
		TyMarks tm=new TyMarks();
		for(int i=0;i<no;i++)
		{
			
			System.out.println("\nEnter Roll no:\t");
			int r=Integer.parseInt(br.readLine());
			System.out.println("enter name: ");
			String nm=br.readLine();
			System.out.println("enter computer marks: ");
			int c=Integer.parseInt(br.readLine());
			System.out.println("enter maths marks: ");
			int m=Integer.parseInt(br.readLine());
			System.out.println("enter electronics marks: ");
			int e=Integer.parseInt(br.readLine());
			System.out.println("enter theory marks: ");
			int th=Integer.parseInt(br.readLine());
			System.out.println("enter practical marks: ");
			int pr=Integer.parseInt(br.readLine());
			sm=new SYMarks(c,m,e);
			tm=new TyMarks(th,pr);
			s[i]=new Student2(r,nm,sm.sytotal,tm.tytotal);
			s[i].findResult();
		}
		for(int i=0;i<no;i++)
			s[i].display();
		// TODO Auto-generated method stub

	}

}
