import java.io.*;
public class SilverCardCustomer implements CreditCardInterface
{
	String name;
	int cardno,creditAmount,creditLimit=50000,cnt=1;
	public SilverCardCustomer()
	{
		creditAmount=0;
		//creditLimit=50000;
	}
	public SilverCardCustomer(String n,int cn)
	{
		name=n;
		cardno=cn;
		
	}
	public void viewCreditAmount()
	{
		System.out.println("\nYour credit amount is:\t"+creditAmount);
	}
	public void useCard() throws IOException
	{	
		viewCreditAmount();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nAmount for Shopping:\t");
		int amt=Integer.parseInt(br.readLine());
		if((creditAmount+amt)<=creditLimit)
		{
			creditAmount+=amt;
			viewCreditAmount();
		}
		else
		{
			System.out.println("\nLOW BALANCE!!!!!\n");
		}
		
	}
	public void payCard()throws IOException
	{
		viewCreditAmount();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nEnter Amount for Paying:\t");
		int amt=Integer.parseInt(br.readLine());
		if((creditAmount-amt)>=0)
		{
			creditAmount-=amt;
		}
		else
		{
			System.out.println("\nINVALID!!!!!\n");
		}
		
		// TODO Auto-generated method stub
		
	}
	public void increaseLimit()
	{
		System.out.println("Not allowed to increase limit as u r silver customer\n");
		// TODO Auto-generated method stub
		
	}
}
