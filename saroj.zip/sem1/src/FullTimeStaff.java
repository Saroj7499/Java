
public class FullTimeStaff extends Staff 
{
	String dept;
	float sal;
	public FullTimeStaff()
	{
		
	}
	public FullTimeStaff(String n,String a,String d,float s)
	{
		super(n,a);
		dept=d;
		sal=s;
	}
	void display()
	{
		super.display();
		System.out.println("\nDepartment:\t"+dept+"\nSalary:\t"+sal);
	}
}
