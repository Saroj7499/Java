import java.io.*;
public class MyNumber 
{
		private int no;
		MyNumber()
		{
			no=0;
		}
		MyNumber(int no)
		{
			this.no=no;
		}
		public void isNegative()
		{
			if(no<0)
				System.out.println("\nNumber is Negative");
		}
		public void isPositive()
		{
			if(no>0)
				System.out.println("\nNumber is Positive");
		}
		public void isZero()
		{
			if(no==0)
				System.out.println("\nNumber is Zero");
			else
				System.out.println("\nNumber is not Zero");
		}
		public void isOdd()
		{
			if(no%2!=0)
				System.out.println("\nNumber is Odd");
		}
		public void isEven()
		{
			if(no%2==0)
				System.out.println("\nNumber is Even");
		}
		

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		MyNumber ob=new MyNumber();
				ob=new MyNumber();
				
				int no=Integer.parseInt(args[0]);
				ob=new MyNumber(no);
				ob.isNegative();
				ob.isPositive();
				ob.isZero();
				ob.isOdd();
				ob.isEven();
		// TODO Auto-generated method stub

	}

}
