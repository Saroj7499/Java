import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Ass6setb1 extends JFrame implements ActionListener
{

	/**
	 * @param args
	 */String str[]={"1","2","3","+","4","5","6","-","7","8","9","*","0",".","=","/"};
		JButton b[]=new JButton [16];
		TextField t1;
		JPanel p;
		String no,s;
		char op;
		/**
		 * @param args
		 */
		public Ass6setb1()
		{
			p=new JPanel();
			setTitle("Simple Calculator");
			t1=new TextField(20);
			p.add(t1);
			add(p);
			for(int i=0;i<str.length;i++)
			{
				b[i]=new JButton(str[i]);
				p.add(b[i]);
				b[i].addActionListener(this);
			}
			add(t1,BorderLayout.NORTH);
			p.setLayout(new GridLayout(4,4));
			add(p,BorderLayout.CENTER);
			setSize(400,400);
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setResizable(false);
		}
		
		public void actionPerformed(ActionEvent e)
		{
			String st=e.getActionCommand();     //get caption of button
			char ch=st.charAt(0);               //get character at first pos of st
			if(ch=='1'||ch=='2'||ch=='3'||ch=='4'||ch=='5'||ch=='6'||ch=='7'||ch=='8'||ch=='9'||ch=='0')
			{
				s=t1.getText()+ch;
				t1.setText(s);
			}
			if(ch=='+'||ch=='-'||ch=='*'||ch=='/')
			{
				op=ch;
				no=t1.getText();
				t1.setText("");
			}
			if(ch=='=')
			{
				switch(op)
				{
					case '+':
								t1.setText(Integer.parseInt(no)+Integer.parseInt(t1.getText())+"");
								break;
					case '-':
								t1.setText(Integer.parseInt(no)-Integer.parseInt(t1.getText())+"");
								break;
					case '*':
								t1.setText(Integer.parseInt(no)*Integer.parseInt(t1.getText())+"");
								break;
					case '/':
								t1.setText(Integer.parseInt(no)/Integer.parseInt(t1.getText())+"");
								break;
				}
			}
		}
		
	public static void main(String[] args)
	{
		new Ass6setb1();
		// TODO Auto-generated method stub

	}

}
