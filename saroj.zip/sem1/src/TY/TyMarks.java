package TY;

 public class TyMarks 
{
	public TyMarks()
	{}
	public int tytotal;
	public TyMarks(int p,int t)
	{
		tytotal=p+t;
		
	}
	
}
