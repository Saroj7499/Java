
public abstract class Shape 
{
	double volume,area;
	abstract void calc_area();
	abstract void calc_volume();
	
}
