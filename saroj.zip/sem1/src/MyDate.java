import java.io.*;
public class MyDate 
{
	static int dd;
	static int mm;
	static int yy;
	public void accept() throws IOException
	{
		try
		{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nEnter date:\t");
		dd=Integer.parseInt(br.readLine());
		System.out.println("\nEnter month :\t");
		mm=Integer.parseInt(br.readLine());
		System.out.println("\nEnter year:\t");
		yy=Integer.parseInt(br.readLine());
		if(mm<=0||mm>12)
			throw new InvalidDateException();
		if(mm==2)
		{
			if(((yy%400==0)&&(yy%4==0))||((yy%100!=0)&&(yy%4==0)))
			{
			if(dd<=0||dd>29)
				throw new InvalidDateException();
			}
			else if(dd<=0||dd>28)
				throw new InvalidDateException();
		}
		if(mm==01||mm==03||mm==05||mm==07||mm==8||mm==10||mm==12)
		{
				if(dd<=0||dd>31)	
					throw new InvalidDateException();
		}
		if(mm==04||mm==06||mm==9||mm==11)
		{
			if(dd<=0||dd>30)
				throw new InvalidDateException();
		}
		
	}
	
		catch (InvalidDateException e)
		{
				// TODO Auto-generated catch block
		}
	}
	public void display(int dd,int mm,int yy)
	{
		System.out.println("\nDate is:\t"+dd+" "+mm+" "+yy);
	}
	public static void main(String[] args) throws IOException
	{
			MyDate ob=new MyDate();
			ob.accept();
			ob.display(dd, mm, yy);
	}
}
