package SY;

 public class SYMarks 
{	
	public SYMarks()
	{
	}
	public int sytotal;
	public SYMarks(int c,int m, int e )
	{
		sytotal=c+m+e;
	}
	
}
