import java.io.*;
public class Student1 
{
	static int count;
	int roll_no;
	String name;
	float per;
	Student1()
	{
	}
	Student1(int r,String n,float p)
	{
		roll_no=r;
		name=n;
		per=p;
	}
	static void displayCount()
	{
		count++;
		System.out.println("Count of object is"+count);
	}
	void display()
	{
		System.out.println("\n Roll number:\t"+roll_no+"\nName:\t"+name+"\nPercentage:\t"+per);
	
	}
	/**
	}
	 * @param args
	 */
	public static void main(String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter array size\n");
		int no=Integer.parseInt(br.readLine());
		Student1 s[]=new Student1[no];
		for(int i=0;i<no;i++)
		{
			s[i]=new Student1();
			System.out.println("\nEnter Roll no:\t");
			int roll_no=Integer.parseInt(br.readLine());
			System.out.println("\nEnter Name\t");
			String name=br.readLine();
			System.out.println("\nEnter percentage:\t");
			float per=Float.parseFloat(br.readLine());
			s[i]=new Student1(roll_no,name,per);
			Student1.displayCount();
		// TODO Auto-generated method stub

		}
		for(int i=0;i<no;i++)
		{
			
			s[i].display();
		}
	}
}