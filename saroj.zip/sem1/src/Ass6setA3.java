import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code="Ass6setA3.class" height=400 width=400>
 * </applet>
 */

public class Ass6setA3 extends Applet implements KeyListener,MouseListener
{
	/**
	 * 
	 */
	
	String str="";
	int x,y;
	public void init()
	{
		addKeyListener(this);
		addMouseListener(this);
	}
	public void paint(Graphics g)
	{
		x=getWidth();
		y=getHeight();
		g.drawString(str,x/2,y/2);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new Ass6setA3();
		// TODO Auto-generated method stub

	}
	public void mouseClicked(MouseEvent e)
	{
		
		if(e.getButton()==1)
		{
			str="You clicked left mouse";
		}
		if(e.getButton()==2)
		{
			str="You clicked wheel mouse";
		}
		if(e.getButton()==3)
		{
			str="You clicked right mouse";
		}
			
		repaint();
		// TODO Auto-generated method stub
		
	}
	public void mousePressed(MouseEvent e) 
	{
		if(e.getButton()==1)
		{
			str="You pressed left mouse";
		}
		if(e.getButton()==2)
		{
			str="You pressed wheel mouse";
		}
		if(e.getButton()==3)
		{
			str="You pressed right mouse";
		}
		repaint();
		// TODO Auto-generated method stub
		
	}
	public void mouseReleased(MouseEvent e) 
	{
		if(e.getButton()==1)
		{
			str="You released left mouse";
		}
		if(e.getButton()==2)
		{
			str="You released wheel mouse";
		}
		if(e.getButton()==3)
		{
			str="You released right mouse";
		}
		repaint();
		// TODO Auto-generated method stub
		
	}
	public void mouseEntered(MouseEvent e)
	{
		str="Mouse is Entered";
		repaint();
		// TODO Auto-generated method stub
		
	}
	public void mouseExited(MouseEvent e)
	{
		str="mouse Exited";
		repaint();
		// TODO Auto-generated method stub
		
	}
	public void keyTyped(KeyEvent e)
	{
		str="key is typed"+" "+e.getKeyChar();
		repaint();
		// TODO Auto-generated method stub
		
	}
	public void keyPressed(KeyEvent e) 
	{
		str="key is pressed"+" "+e.getKeyChar();
		repaint();
		// TODO Auto-generated method stub
		
	}
	public void keyReleased(KeyEvent e) 
	{
		str="key is released"+" "+e.getKeyChar();
		repaint();
		// TODO Auto-generated method stub
		
	}

}
