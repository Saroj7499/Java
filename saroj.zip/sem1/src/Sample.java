
public class Sample
{
	int rollNumber;
	String name;
	static String classTeacher;
	Sample(int r,String n)
	{
		rollNumber=r;
		name=n;
	}
	static void assignTeacher(String name)
	{
		classTeacher=name;
	}
	public String toString()
	{
		return"["+rollNumber+","+name+","+classTeacher+"]";
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Sample s1=new Sample(1,"A");
		Sample s2=new Sample(2,"B");
		Sample.assignTeacher("ABC");
		System.out.println(s1);
		System.out.println(s2);// TODO Auto-generated method stub

	}

}
