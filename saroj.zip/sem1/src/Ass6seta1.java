import javax.swing.*;
import java.awt.event.*;
import java.awt.font.TextAttribute;
import java.awt.*;
import java.util.*;

public class Ass6SetA1 extends JFrame implements ItemListener 
{
	JLabel l1,l2,l3;
	JCheckBox c1,c2,cb3;
	JComboBox cb1,cb2;
	TextField t;
	JPanel p;
	
	public Ass6SetA1()
	{
		l1=new JLabel("Font");
		l2=new JLabel("Style");
		l3=new JLabel("Size");
		c1=new JCheckBox("Bold");
		c1.addItemListener(this);
		c2=new JCheckBox("Italic");
		c2.addItemListener(this);
		cb3=new JCheckBox("Underline");
		cb1=new JComboBox();
		cb2=new JComboBox();
		
		t=new TextField(30);
		p=new JPanel();
		p.setLayout(new GridLayout(4,2));
		
		add(p,BorderLayout.CENTER);
		p.add(l1);p.add(l2);
		p.add(cb1);p.add(c1);
		p.add(l3);p.add(c2);
		p.add(cb2);
		p.add(cb3);
		cb1.addItem("ARIAL");
		cb1.addItem("CALIBRI");
		cb1.addItem("Sans-Serif");
		cb1.addItem("Verdana");
		cb1.addItem("Times New Roman");
		cb1.addItem("Helvetica");
		cb1.addItem("ukai");
		cb1.addItem("lohit-gujarati");
		for(int i=0;i<10;i++)
		{
			cb2.addItem(i+1+"");
		}
		cb1.addItemListener(this);
		cb2.addItemListener(this);
		add(t,BorderLayout.SOUTH);
		cb3.addItemListener(this);
		setSize(400,400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		
		String s=t.getText();
		int t1=0;
		if(c1.isSelected())
		{
			t1=t1+Font.BOLD;
		}
		if(c2.isSelected())
		{
			t1=t1+Font.ITALIC;
		}
		
		
		String s1=(String)(cb1.getSelectedItem());
		System.out.println(s1);
		int a=Integer.parseInt(cb2.getSelectedItem()+"");
		System.out.println(a);
		Font f=new Font(s1,t1,a);
		t.setFont(f);
		t.setText(s);
		if(cb3.isSelected())
		{
			f=t.getFont();
		Map attributes = f.getAttributes();
		attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
		t.setFont(f.deriveFont(attributes));
		}
		
		
		
	}

	public static void main(String[] args)
	{
		new Ass6SetA1();
	}
}
