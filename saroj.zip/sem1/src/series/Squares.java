package series;

public class Squares
{
	public void findSquares(int no)
	{
		int a;
		System.out.println("\nSquare seriesis:\t");
		for(int i=0;i<no;i++)
		{
			a=i*i;
			System.out.println(a);
		}
	}
}
