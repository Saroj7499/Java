package series;

public class Prime 
{
	public void findPrime(int no)
	{
		int cnt=1,flag=0,i=3;
		while(cnt<=no)
		{
			flag=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
				{
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println(i+",");
				cnt++;
			}
			i++;
		}
	}
	
}
