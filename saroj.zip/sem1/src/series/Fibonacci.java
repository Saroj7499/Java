package series;

public class Fibonacci 
{
	public void findFibonacci(int no)
	{
		int x=0,y=1,z,cnt=3;
		System.out.println("\nFibonacci seriesis:\n"+x+","+"\n"+y+",");
		while(cnt<=no)
		{
			z=x+y;
			System.out.println(z+",");
			x=y;
			y=z;
			cnt++;
		}
		
	}
}
