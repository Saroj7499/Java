import java.io.*;
public class Demoem {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nEnter size of array\t");
		int no=Integer.parseInt(br.readLine());
		Manager m[]=new Manager[no];
		for(int i=0;i<no;i++)
		{
			System.out.println("\nEnter Employee-id:\t");
			int id=Integer.parseInt(br.readLine());
			System.out.println("\nEnter Name:\t");
			String name=br.readLine();
			System.out.println("\nEnter department:\t");
			String dept=br.readLine();
			System.out.println("\n Enter Salary:\t");
			float salary=Float.parseFloat(br.readLine());
			System.out.println("\nEnter Bonus:\t");
			float bonus=Float.parseFloat(br.readLine());
			m[i]=new Manager(id,name,dept,salary,bonus);
			m[i].tolSal();
			
		}
		for(int i=0;i<no;i++)
		{
			m[i].display();
		}
		
		float max=m[0].total;
		int n=0;
		for(int i=1;i<no;i++)
		{
			if(m[i].total>max)
			{
				max=m[i].total;
				n=i;
			}	
		}
		System.out.println("\nMaximum Salary is:\t");
		m[n].display();
				
		// TODO Auto-generated method stub

	}

}
