
public class InvalidDateException extends Exception 
{
	public InvalidDateException()
	{
		System.out.println("Invalid Date:....");
	}
}
