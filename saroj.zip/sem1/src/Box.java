
public class Box extends Shape
{
	double len,bre,height;
	public Box()
	{
		
	}
	public Box(double l,double b,double h)
	{
		len=l;
		bre=b;
		height=h;
	}
	void calc_area()
	{
		area=2*((len*bre)+(bre*height)+(height*len));
		System.out.println("\nArea of box is:\t"+area);
	}
	void calc_volume()
	{
		volume=len*bre*height;
		System.out.println("\nVolume of box is:\t"+volume);
	}
}
