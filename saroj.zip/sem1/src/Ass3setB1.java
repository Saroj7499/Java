import java.io.*;


public class Ass3setB1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nEnter array size:\t");
		int no=Integer.parseInt(br.readLine());
		FullTimeStaff ob[]=new FullTimeStaff[no];
		PartTimeStaff ob1[]=new PartTimeStaff[no];
		int fc=0,pc=0;
		for(int i=0;i<no;i++)
		{
			System.out.println("\nEnter name:\t");
			String name=br.readLine();
			System.out.println("\nEnter address:\t");
			String add=br.readLine();
			System.out.println("\nEnter 1 for FullTimeStaff \n 2 for PartTimeStaff:\t");
			int op=Integer.parseInt(br.readLine());
			if(op==1)
			{
				System.out.println("\nEnter department:\t");
				String dept=br.readLine();
				System.out.println("\nEnter salary:\t");
				float sal=Float.parseFloat(br.readLine());
				ob[fc]=new FullTimeStaff(name,add,dept,sal);
				fc++;
			}
			else
			{
				System.out.println("\nEnter Number of hours:\t");
				int hrs=Integer.parseInt(br.readLine());
				System.out.println("\nEnter Rate per hours:\t");
				float r_p_h=Float.parseFloat(br.readLine());
				ob1[pc]=new PartTimeStaff(name,add,hrs,r_p_h);
				pc++;
			}
		}
			for(int  i=0;i<fc;i++)
			{
				ob[i].display();
			}
			for(int  i=0;i<pc;i++)
			{
				ob1[i].display();
			}
		
		// TODO Auto-generated method stub

	}

}
