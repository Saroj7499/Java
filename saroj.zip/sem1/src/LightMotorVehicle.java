
public class LightMotorVehicle extends Vehicle
{
	float mileage;
	LightMotorVehicle(String c,float p, float m)
	{
		super(c,p);
		mileage=m;
	}
	void displayl()
	{
		super.display();
		System.out.println("\nMileage of Vehical is:\t"+mileage);
	}
}
