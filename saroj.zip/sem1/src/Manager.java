
public class Manager extends Employee
{	
	float total;
	private float bonus;
	Manager()
	{
	}
	Manager(int i,String n,String d,float s,float b)
	{
		super(i,n,d,s);
		bonus=b;
	}
	void display()
	{
		super.display();
		System.out.println("\nBonus:\t"+bonus+"\nTotal\t"+total);
	}
	void tolSal()
	{
		float sa;
		sa=getSal();
		total=sa+bonus;
	}
	
}
