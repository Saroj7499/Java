
public class Cone extends Shape
{
	double rad,height;
	public Cone()
	{
		
	}
	public Cone(double r,double h)
	{
		rad=r;
		height=h;
	}
	void calc_area()
	{
		area=3.14*rad*(rad+Math.sqrt((height*height)+(rad*rad)));
		System.out.println("\nArea of Cone is:\t"+area);
	}
	void calc_volume()
	{
		volume=3.14*rad*rad*(height/3);
		System.out.println("\nVolume of Cone is:\t"+volume);
	}
}
