import javax.swing.*;
import java.awt.*;
import java.awt.event;

class Ass6SetB2 extends JFrame
{
	JLabel l1;
	JMenuBar jb;
	JMenu j1,j2,j3,j4;
	JMenuItem l,s,ex,sum,avg,max,min,med,srch;
	JRadioButtonMenuItem r1,r2;
	JPanel p1,p2;
	JTextArea ta;	
	public Ass6SetB2()
	{
		p1=new JPanel();
		p2=new JPanel();
		ta=new TextArea(5,20);
		l1=new JLabel("Number");
		jb=new JMenuBar();
		j1=new JMenu("File");
		j2=new JMenu("Compute");
		j3=new JMenu("Operations");
		j4=new JMenu("Sort");
		r1=new JRadioButtonMenuItem("Ascending");
		r2=new JRadioButtonMenuItem("Descending");
		l=new JMenuItem("Load");
		s=new JMenuItem("Save");
		ex=new JMenuItem("Exit");
		sum=new JMenuItem("Sum");
		avg=new JMenuItem("Average");
		max=new JMenuItem("Maximum");
		min=new JMenuItem("Minimum");
		med=new JMenuItem("Median");
		srch=new JMenuItem("Search");
		add(p1,BorderLayout.SOUTH);
	}
}


