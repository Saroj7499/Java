
public class HeavyMotorVehicle extends Vehicle 
{
	float capacity;
	HeavyMotorVehicle(String c,float p,float ca)
	{
		super(c,p);
		capacity=ca;
	}
	void display()
	{
		super.display();
		System.out.println("\nCapacity in tones:\t"+capacity);
	}
}
