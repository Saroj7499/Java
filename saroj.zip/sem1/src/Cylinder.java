
public class Cylinder extends Shape
{
 	double rad,height;
 	public Cylinder()
 	{
 		
 	}
	public Cylinder(double r,double h)
	{
		rad=r;
		height=h;
	}
	void calc_area()
	{
		area=(2*3.14*rad*height)+(2*3.14*rad*rad);
		System.out.println("\nArea of Cylinder is:\t"+area);
	}
	void calc_volume()
	{
		volume=3.14*rad*rad*height;
		System.out.println("\n Voulme of Cylinder is:\t"+volume);
	}
}
