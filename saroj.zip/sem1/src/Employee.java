
public class Employee 
{
	private int id;
	private String name,dept;
	private float salary;
	 Employee()
	 {
		 
	 }
	 Employee(int i,String n,String d,float s)
	 {
		 id=i;
		 name=n;
		 dept=d;
		 salary=s;
	 }
	 float getSal()
	 {
		 return salary;
	 }
	 void display()
	 {
		 System.out.println("\nEmployee id:\t"+id+"\nName:\t"+name+"\nDepartment:\t"+dept+"\nSalary:\t"+salary);
	 }
}
