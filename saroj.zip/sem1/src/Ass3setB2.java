import java.io.*;
public class Ass3setB2
{

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("\nEnter name of customer for Silver card:\t");
		String names=br.readLine();
		System.out.println("\nEnter Card Number:\t");
		int cardnos=Integer.parseInt(br.readLine());
		
		System.out.println("\nEnter name of customer for Gold card:\t");
		String nameg=br.readLine();
		System.out.println("\nEnter Card Number:\t");
		int cardnog=Integer.parseInt(br.readLine());
		
		
		SilverCardCustomer ob= new SilverCardCustomer(names,cardnos);
		GoldCardCustomer ob1= new GoldCardCustomer(nameg,cardnog);
		while(true)
		{
			System.out.println("1usecard\n2.paycredit\n3.increase limit\n4.exit\nenter your choice:");
			int ch=Integer.parseInt(br.readLine());
			
		
		
		
		switch(ch)
		{
		
		case 1:	
			System.out.println("\nEnter 1 for Silvercard customer \n 2 for Goldcard customer");
			int op=Integer.parseInt(br.readLine());
		
		if(op==1)
			
		{
			ob.viewCreditAmount();
			ob.useCard();
		}
		if(op==2)
		{

			ob1.viewCreditAmount();
			ob1.useCard();
		}
		break;
		case 2:	
			System.out.println("\nEnter 1 for Silvercard customer \n 2 for Goldcard customer");
			int op1=Integer.parseInt(br.readLine());
		
		if(op1==1)
			
		{
			ob.viewCreditAmount();
			ob.payCard();
			ob.viewCreditAmount();
		}
		if(op1==2)
		{

			ob1.viewCreditAmount();
			ob1.payCard();
			ob1.viewCreditAmount();
		}
		break;
		case 3:
			System.out.println("\nEnter 1 for Silvercard customer \n 2 for Goldcard customer");
			int op2=Integer.parseInt(br.readLine());
		
		if(op2==1)
			
		{
			System.out.println("THIS OPTION IS FOR GOLDCLASS CUSTOMER ONLY\n");
		}
		if(op2==2)
		{

			ob1.viewCreditAmount();
			ob1.increaseLimit();
		}
		break;
		case 4:
			System.exit(0);
			break;
		}
		}
		
	}
}
