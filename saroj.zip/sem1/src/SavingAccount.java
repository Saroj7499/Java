import java.io.*;
public class SavingAccount 
{
		int acNo;
		String name;
		float balance;
	public SavingAccount(int an,String n,float b)
	{
		acNo=an;
		name=n;
		balance=b;
	}
	public void withdraw(float amt)
	{
		try
		{
			if((balance-amt)<=500)
				throw new InsufficientFundsException();
			else
			{
				balance-=amt;
			System.out.println("Your transaction is successful!!\n Balance is:"+balance);
			
			}
			
		}
		catch(InsufficientFundsException e)
		{
			System.out.println("\n Sorry Insufficient Blance!!!");
		}
	}
	public void deposit(float amt)
	{
		balance+=amt;
		System.out.println("Your amount is successfully deposited\n");
		
	}
	public void viewBalance()
	{
		System.out.println("Your Balance is:\n"+balance);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException
	{
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Account number: \t");
		int acno=Integer.parseInt(br.readLine());
		System.out.println("ENter name:\t");
		String name=br.readLine();
		System.out.println("Enter your balance");
		float bal=Float.parseFloat(br.readLine());
		SavingAccount ob=new SavingAccount(acno,name,bal);
		while(true)
		{
			System.out.println("*****MENU*****\n1.Withdraw\n2.Deposit\n3.View Balance\n4.Exit\nEnter your choice\n");
			int ch=Integer.parseInt(br.readLine());
		
			switch(ch)
			{
			case 1:
				System.out.println("Enter amount to be withdraw\n");
				float amt=Float.parseFloat(br.readLine());
				ob.withdraw(amt);
				break;
			case 2:
				System.out.println("Enter amount to be withdraw\n");
				float amt1=Float.parseFloat(br.readLine());
				ob.deposit(amt1);
				ob.viewBalance();
				break;
			case 3:
				ob.viewBalance();
				break;
			case 4:
				System.exit(0);
				break;
			default:
				System.out.println("Enter correct choice\n");
				break;
				
		}
	}
		// TODO Auto-generated method stub

	}

}
