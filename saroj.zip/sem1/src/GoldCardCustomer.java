 
public class GoldCardCustomer extends SilverCardCustomer
{ 	int creditLimit=100000;
	static int cnt;
	public GoldCardCustomer()
	{
		creditAmount=0;
		//creditLimit=100000;
	}
	public GoldCardCustomer(String n,int cn)
	{
		name=n;
		cardno=cn;
	
	}
	public void increaseLimit()
	{
		if(cnt<3)
		{
			creditLimit+=5000;
			cnt++;
			System.out.println("\nCredit limit is:\t"+creditLimit);
		}
		else
			System.out.println("\nLIMIT EXCEEDS\n");
	}

}
