
public class Ass3setA2 
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Sphere ob=new Sphere();
		ob= new Sphere(2.2);
		ob.calc_area();
		ob.calc_volume();
		Cone  ob1=new Cone();
		ob1=new Cone(2.2,3.4);
		ob1.calc_area();
		ob1.calc_volume();
		Cylinder ob2=new Cylinder();
		ob2= new Cylinder(2.2,3.2);
		ob2.calc_area();
		ob2.calc_volume();
		Box ob3=new Box();
		ob3= new Box(2.2,2.2,2.2);
		ob3.calc_area();
		ob3.calc_volume();
		// TODO Auto-generated method stub

	}

}
