import series.*;
public class Demo1
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		System.out.println("Prime numbers are:\t");
		Prime ob=new Prime();
		ob.findPrime(4);
		Fibonacci ob1=new Fibonacci();// TODO Auto-generated method stub
		ob1.findFibonacci(7);
		Squares ob3=new Squares();
		ob3.findSquares(11);
	}

}
