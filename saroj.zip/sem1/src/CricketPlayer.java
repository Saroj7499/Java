import java.io.*;
public class CricketPlayer 
{
	String name;
		int noofin;
		int nont;
		int runs;
		float avg;
		public CricketPlayer(String n,int in,int no,int r)
		{
			name=n;
			noofin=in;
			nont=no;
			runs=r;
		
		}
		static void avg(CricketPlayer c[])
		{
			try
			{
				for(int i=0;i<c.length;i++)
				{
					c[i].avg=((c[i].runs)/(c[i].noofin-c[i].nont));
				}
				
			}
			catch(ArithmeticException e)
			{
				System.out.println("ARITHMETIC EXCEPTION\n");			
			}
		catch(NumberFormatException e)
		{
			System.out.println("NUMBER FORMAT EXCEPTION\n");
		}
		catch(Exception e)
		{
			System.out.println("Exception arise!!!");
		}
		}
		static void sortPlayer(CricketPlayer c[])
		{
			CricketPlayer temp;
			for(int i=0;i<c.length;i++)
			{
				for(int j=i+1;j<c.length;j++)
				{
					if(c[i].avg<c[j].avg)
					{
						temp=c[i];
						c[i]=c[j];
						c[j]=temp;
					}
				}
			}
		}
	public void display()
	{
		System.out.println("\nName:\t"+name+"\nNumber of INN:\t"+noofin+"\nNumber of Times not out:\t"+nont+"\nTotal.number of RUNS:\t"+runs);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter size of array\t");
		int no=Integer.parseInt(br.readLine());
		CricketPlayer cp[]=new CricketPlayer[no];
		for(int i=0;i<no;i++)
		{
			System.out.println("Enter NAme:\t");
			String name=br.readLine();
			System.out.println("Enter number of INN:\t");
			int in=Integer.parseInt(br.readLine());
			System.out.println("Enter number of NOTOUT:\t");
			int not=Integer.parseInt(br.readLine());
			System.out.println("Enter RUNS:\t");
			int runs=Integer.parseInt(br.readLine());
			cp[i]=new CricketPlayer(name,in,not,runs);
			
		}
		CricketPlayer.avg(cp);
		System.out.println("\nDetails Of players are:\t");
		for(int i=0;i<no;i++)
		{
			cp[i].display();
		}
		CricketPlayer.sortPlayer(cp);
		System.out.println("\nSorted players are:\t");
		for(int i=0;i<no;i++)
		{
			cp[i].display();
		}
		// TODO Auto-generated method stub

	}

}
