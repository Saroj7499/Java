import java.io.*;

public class Student 
{
	int roll_no,m1,m2,m3;
	String name,add;
	float per;
	void getData(int r,String n,int p,int s,int t,String a)
	{
		roll_no=r;
		name=n;
		m1=p;
		m2=s;
		m3=t;
		add=a;
	
	}
	void display()
	{
		System.out.println("\n Roll No:\t"+roll_no+"\nName:\t"+name+"\nSubject 1:\t"+m1+"\nSubject 2:\t"+m2+"\nSubject 3:\t"+m3+"\nAddress:\t"+add+"\nPercentage:\t"+per);
	}
	void findResult()
	{
		per=((m1+m2+m3)/300.00f)*100.00f;
	}
	static void sort(Student s1[])
	{
		Student temp;
		for(int i=0;i<s1.length;i++)
		{
			for(int j=i+1;j<s1.length;j++)
			{
				if(s1[i].per<s1[j].per)
				{
					temp=s1[i];
					s1[i]=s1[j];
					s1[j]=temp;
				}
			}
		}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter array size:\t");
		int no=Integer.parseInt(br.readLine());
		Student s[]=new Student[no];
		for(int i=0;i<no;i++)
		{
			s[i]=new Student();
			System.out.println("\nEnter Roll no:\t");
			int roll_no=Integer.parseInt(br.readLine());
			System.out.println("\nEnter Name\t");
			String name=br.readLine();
			System.out.println("\nEnter marks of subject1:\t");
			int m1=Integer.parseInt(br.readLine());
			System.out.println("\nEnter marks of Subject2:\t");
			int m2=Integer.parseInt(br.readLine());
			System.out.println("\nEnter marks of Subject3:\t");
			int m3=Integer.parseInt(br.readLine());
			System.out.println("\nEnter your address:\t");
			String add=br.readLine();
			System.out.println("\nEnter info of next person:\t");
			s[i].getData(roll_no, name, m1, m2, m3, add);
			
		}
		for(int i=0;i<no;i++)
		{
			s[i].findResult();
		}
		for(int i=0;i<no;i++)
		{
			
			s[i].display();
		}
		Student.sort(s);

			System.out.println("\nYour sorted array is:\t");
			for(int i=0;i<no;i++)
			{
					s[i].display();
			}
		
		// TODO Auto-generated method stub

	}

}
