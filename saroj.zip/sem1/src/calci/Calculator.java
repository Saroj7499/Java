package calci;

public class Calculator 
{
	public void add(int no1,int no2)
	{
		System.out.println("\nAddition of two no's =\t"+(no1+no2));
	}
	public void sub(int no1,int no2)
	{
		System.out.println("\nSubstraction of two no's=\t"+(no1-no2));
	}
	public void mult(int no1, int no2)
	{
		System.out.println("\nMultiplication of two no's=\t"+(no1*no2));
	}
	public void div(int no1,int no2)
	{
		System.out.println("\nDivision of two no's=\t"+(no1/no2));
	}
}
