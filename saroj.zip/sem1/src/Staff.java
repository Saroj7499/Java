
public abstract class Staff
{
	String name,add;
	public Staff()
	{
		
	}
	public Staff(String n,String a)
	{
		name=n;
		add=a;
	}
	void display()
	{
		System.out.println("\nName is:\t"+name+"\nAddress:\t"+add);
	}
}
