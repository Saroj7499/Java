
public class PartTimeStaff extends Staff
{
	int hrs;
	float r_p_h;
	public PartTimeStaff()
	{
		
	}
	public PartTimeStaff(String n,String a,int h,float r)
	{
		super(n,a);
		hrs=h;
		r_p_h=r;
	}
	void display()
	{
		super.display();
		System.out.println("\nHours:\t"+hrs+"\nRate per Hours:\t"+r_p_h);
	}
}
